<?php

class miclase {
    public function__construct() {
        echo"Mi Clase ha sido agregada!!!<br>";
    }
}
?>