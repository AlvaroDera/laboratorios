<?php

class miotraclase {
    public function__construct() {
        echo"Mi segunda Clase ha sido agregada!!!<br>";
        }
    }
?>