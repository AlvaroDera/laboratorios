<!DOCTYPE html>
<html lang="en">
<head>
    <title>laboratorio 1.3</title>
</head>
<body>
    <?php
    echo phpinfo();
    ?>
</body>
</html>