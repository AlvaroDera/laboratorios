<!DOCTYPE html>
<head>
    <title>laboratorio 1.1</title>
</head>
<body>
    <?php
    $ini = "Hola";
    $fin = "Todos";
    $todo = $ini.$fin;
    echo = $todo;
    ?>
</body>
</html>