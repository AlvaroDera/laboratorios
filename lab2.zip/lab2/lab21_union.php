<?php include("lab21_header.php"); #Include para hacer el llamado?> 
<p> Hola, este es el contenido. </p>

<?php include("lab21_footer.php");?> 
