<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>laboratorio 2.6</title>
</head>
<body>
    <?php
    $a = 5;
    $b = "5";
    echo ($a == 5) ? "verdadero" : "falso", "<br>";
    echo ($a === 5) ? "verdadero" : "falso", "<br>";
    echo ($b == 5) ? "verdadero" : "falso", "<br>";
    echo ($b === 5) ? "verdadero" : "falso", "<br>";
    ?>
</body>
</html>