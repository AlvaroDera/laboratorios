<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>laboratorio 2.9</title>
</head>
<body>
    <?php
    for($i = 0 ; $i < 10 ; $i++) {
        echo "El valor de i es ", $i,"<br>";
    }
    ?>
</body>
</html>