<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Parcial 1 </title>
</head>
<body>
<?php

$valor [0] [0] = 0; $valor [0] [1] = 0; $valor [0] [2] = 0; $valor [0] [3] = 0; $valor [0] [4] = rand(101,200); 

$valor [1] [0] = 0; $valor [1] [1] = 0; $valor [1] [2] = 0; $valor [1] [3] = rand(101,200); $valor [1] [4] = 0;

$valor [2] [0] = 0; $valor [2] [1] = 0; $valor [2] [2] = rand(101,200); $valor [2] [3] = 0; $valor [2] [4] = 0;

$valor [3] [0] = 0; $valor [3] [1] = rand(101,200); $valor [3] [2] = 0; $valor [3] [3] = 0; $valor [3] [4] = 0;

$valor [4] [0] = rand(101,200); $valor [4] [1] = 0; $valor [4] [2] = 0; $valor [4] [3] = 0; $valor [4] [4] = 0;

echo "<table border=1>";

echo "<tr>";
echo " <td>" . $valor[0][0] . "</td>";
echo " <td>" . $valor[0][1] . "</td>";
echo " <td>" . $valor[0][2] . "</td>";
echo " <td>" . $valor[0][3] . "</td>";
echo " <td>" . $valor[0][4] . "</td>";
echo "</tr>";

echo "<tr>";
echo " <td>" . $valor[1][0] . "</td>";
echo " <td>" . $valor[1][1] . "</td>";
echo " <td>" . $valor[1][2] . "</td>";
echo " <td>" . $valor[1][3] . "</td>";
echo " <td>" . $valor[1][4] . "</td>";
echo "</tr>";

echo "<tr>";
echo " <td>" . $valor[2][0] . "</td>";
echo " <td>" . $valor[2][1] . "</td>";
echo " <td>" . $valor[2][2] . "</td>";
echo " <td>" . $valor[2][3] . "</td>";
echo " <td>" . $valor[2][4] . "</td>";
echo "</tr>";

echo "<tr>";
echo " <td>" . $valor[3][0] . "</td>";
echo " <td>" . $valor[3][1] . "</td>";
echo " <td>" . $valor[3][2] . "</td>";
echo " <td>" . $valor[3][3] . "</td>";
echo " <td>" . $valor[3][4] . "</td>";
echo "</tr>";

echo "<tr>";
echo " <td>" . $valor[4][0] . "</td>";
echo " <td>" . $valor[4][1] . "</td>";
echo " <td>" . $valor[4][2] . "</td>";
echo " <td>" . $valor[4][3] . "</td>";
echo " <td>" . $valor[4][4] . "</td>";
echo "</tr>";

echo "</table>";

   ?>
</body>
</html>